# curriculum-vitae
curriculum vitae echo en Html y Css.



![Captura de pantalla (150)](https://user-images.githubusercontent.com/74312596/151689443-b980b350-ae5b-4ed0-90e0-79d0eb6618cd.png)

